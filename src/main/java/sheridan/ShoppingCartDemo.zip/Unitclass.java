package sheridan;


public class Unitclass {
    public static double TwoSecarerio(double Size)
    {
        if(Size < 0){
            return 0;
        }
           else
        {
        return Size;
    }
    }
}

