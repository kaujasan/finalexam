package sheridan;

/*
Raj
----------------------------------------------------------------------
 */

/**
 *
 * @author Raj
 */
public class factory {
    
    private double Discount;
    double DiscountByAmount;
        double DiscountByperctg ;
    private static factory DiscountObject = null;

   
    
public void addFactory(){
    
}
public static factory getInstance() {
if(DiscountObject==null)
{
    DiscountObject = new factory();
}
return DiscountObject;
}
}
