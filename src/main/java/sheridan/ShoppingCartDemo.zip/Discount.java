package sheridan;

/*

----------------------------------------------------------------------
 */

/**
 *
 * @author jasanpreet 
 */
public class Discount {
   public static void main(String args[])
	{
    
        double dollar;
        
        
	double DiscountByAmount =900;
        double DiscountBypercentage=25;  // 25 mean 25%			
	
	System.out.println ("DiscountByAmount= "+ DiscountByAmount);
        System.out.println("discount rate="+DiscountBypercentage);
         
        dollar=100-DiscountBypercentage;
 
	dollar= (dollar*DiscountByAmount)/100;
 
	System.out.println("amount after discount="+dollar);
 
	}

    Discount(String fist, int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

} 

